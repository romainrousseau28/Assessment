<?php
require_once 'core/init.php';
include 'includes/head.php';




 $name = ((isset($_POST['name'])) ? sanitize($_POST['name']) : '');
	$email = ((isset($_POST['email'])) ? sanitize($_POST['email']) : '');
	$subject = ((isset($_POST['subject'])) ? sanitize($_POST['subject']) : '');
	$msg = ((isset($_POST['msg'])) ? sanitize($_POST['msg']) : '');


	 if ($_POST) {
		 $emailQuery = $db->query("SELECT * FROM feedback WHERE email = '$email'");
		 $emailCount = mysqli_num_rows($emailQuery);

		 if ($emailCount != 0) {
			 $errors[] = 'That email already exists in our database.';
		 }

		 $required = array('name', 'email','subject','msg');
		 foreach ($required as $f) {
			 if (empty($subject)) {
				 $errors[] = 'Title is required.';
				 break;
			 }
		 }
		 if (strlen($msg) >= 400) {
			 $errors[] = 'Body must be less than 400 characters.';
		 }


		 if (!empty($errors)) {
	     echo display_errors($errors);
	   } else {
			 // Add user to database
			 if (isset($_GET['add'])) {
				 $db->query("INSERT INTO feedback (name, email, subject, msg) VALUES ('$name', '$email', '$subject', '$msg')");
				 $_SESSION['success_flash'] = 'successfully added! ';
				 header('Location: MCB.php');

	   }
	 }
	 }

//Delete records
if(isset($_GET['delete']) && !empty($_GET['delete'])){
  $delete_id = (int)$_GET['delete'];
  $delete_id = sanitize($delete_id);
  $sql = "DELETE FROM feedback WHERE id = '$delete_id'";
  $db->query($sql);
  header('Location: MCB.php');
}

$sqlw = "SELECT * FROM feedback";
$p_result = $db->query($sqlw);


?>


  <body>
	<br></br>

	<h2 class="text-center">Form</h2><hr>
  <center>
	<form action="MCB.php?add" method="POST" >
		<div class="form-group col-md-6">
			<label for="name">Username :</label>
			<input type="text" name="name" id="name" class="form-control" value="<?= $name; ?>">
		</div>
		<div class="form-group col-md-6">
			<label for="email">Email :</label>
			<input type="text" name="email" id="email" class="form-control" value="<?= $email; ?> ">
		</div>
		<div class="form-group col-md-6">
			<label for="subject">Title :</label>
			<input type="text" name="subject" id="subject" class="form-control" value="<?= $subject; ?>">
		</div>
		<div class="form-group col-md-6">
			<label for="msg">Body :</label>
			<input type="text" name="msg" id="msg" class="form-control" value="<?= $msg; ?>">
		</div>

		<div class="form-group col-md-6 text-right" style="margin-top: 25px;">

		<center>
      	<a href="MCB.php" class="btn btn-danger">Cancel</a>
      <input type="submit" value="Post" class="btn btn-success"></center>
		</div>

	</form></center>
</body>
<br></br>


<br></br>
<h3 class="text-center">Table</h3>
<html>

	<body>
		<form class method="post" action="MCB.php">
			<input  type="text" name="q" placeholder="">
			<select class="btn btn-info" name="column">
				<option value="">Select Filter</option>
				<option value="">Title</option>
				<option value="price">Body</option>


			</select>
			<input class="btn btn-info" type="submit" name="submit" value="Find">
		</form>
	</body>
</html>

<div class="clearfix"></div>

<table class="table table-bordered table-condensed talbe-striped">
 <thead>
   <th>Username</th>
   <th>Email</th>
   <th>Title</th>
	 <th>Body</th>



 </thead>

 <tbody>



<?php while ($feedback = mysqli_fetch_assoc($p_result)) : ?>
    <tr>



     <td><?php echo $feedback['name']; ?></td>

     <td><?php echo ($feedback['email']); ?></td>
<td><?php echo ($feedback['subject']); ?></td>
     <td><?php echo ($feedback['msg']); ?></td>
     <td><a href="MCB.php?delete=<?=$feedback['id']; ?>" class="btn btn-primary" ><span class="glyphicon glyphicon-remove-sign"></span>Delete</button></td>





    </tr>

<?php endwhile; ?>
 </tbody>

</table>

<a class="btn btn-warning" href="read_and_export.php" target="_new" ><i class="fa fa-download"></i> Export to Excel</a>
<form action="#" method="post">

</form>
<br></br> <br></br>
</body>
